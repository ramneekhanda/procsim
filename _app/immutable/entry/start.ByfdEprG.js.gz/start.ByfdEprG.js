import{a as t}from"../chunks/entry.CoPxwxZF.js";export{t as start};
