import{a as t}from"../chunks/entry.D4MiQ01B.js";export{t as start};
