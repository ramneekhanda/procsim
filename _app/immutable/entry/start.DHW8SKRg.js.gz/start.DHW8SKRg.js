import{a as t}from"../chunks/entry.CWmbZpRJ.js";export{t as start};
