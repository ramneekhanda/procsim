import{a as t}from"../chunks/entry.DHxu1igr.js";export{t as start};
