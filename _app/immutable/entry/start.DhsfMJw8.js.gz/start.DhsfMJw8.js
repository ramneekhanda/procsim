import{a as t}from"../chunks/entry.Zjc_hdxG.js";export{t as start};
