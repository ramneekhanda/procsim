import{a as t}from"../chunks/entry.B0OXlEow.js";export{t as start};
