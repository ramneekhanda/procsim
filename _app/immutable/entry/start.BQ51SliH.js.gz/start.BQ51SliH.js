import{a as t}from"../chunks/entry.BJVeTgoP.js";export{t as start};
