import{a as t}from"../chunks/entry.BYBwFC73.js";export{t as start};
