import{a as t}from"../chunks/entry.DtvctO_s.js";export{t as start};
