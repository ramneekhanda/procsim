import{a as t}from"../chunks/entry.BcGhTVF6.js";export{t as start};
