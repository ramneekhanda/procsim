import{a as t}from"../chunks/entry.ChFpSBvk.js";export{t as start};
